import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:googlesignin/profilePage.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flare_flutter/flare_actor.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin{

  AnimationController _controller;
  Animation animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 200 ),lowerBound: 0,upperBound: 4,
      vsync: this,
    )..addListener(() {
      setState(() {

      });})..addStatusListener((status) {if(status == AnimationStatus.completed){
      _controller.reverse();
    }else if (status == AnimationStatus.dismissed){_controller.forward();}});
    animation = Tween(begin: 0, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.bounceIn));
    _controller.forward();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.deepOrangeAccent,
      body:

         Container(
            child: Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[

                FlareActor("assets/confetti.flr",alignment: Alignment.topCenter,fit: BoxFit.contain,animation: "confetti shu 2",),



                              Positioned(top: 200,
                                child: AnimatedBuilder(

                                animation: _controller,
                                builder: (BuildContext context, Widget child){
                                  return Transform(
                                    transform: Matrix4.translationValues(0,_controller.value*2 ,0),
                                    child:Image.asset(
                                      'assets/agreement.png',
                                      height: 120.0,width: 70,
                                    ),

                                  );}),
                              ),






                Positioned( top: 290,  child: Container(child: Text("Welcome!", style: TextStyle(fontSize: 40,color: Colors.white,fontFamily: 'BalooBhaina',fontWeight: FontWeight.w400),))),

                Positioned(top: 380,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(30.0, 5.0, 30.0, 5.0),
                    child: new RaisedButton(
                        padding: EdgeInsets.only(top: 3.0,bottom: 3.0,left: 3.0),
                        color: const Color(0xFF4285F4),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) =>   ProfilePage()),
                          );
                        },
                        child: new Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[

                            new Container(
                                padding: EdgeInsets.only(left: 10.0,right: 10.0),
                                child: Row(
                                  children: <Widget>[
                                    new Text("Sign in with ",style: TextStyle(color: Colors.white,fontFamily: 'BalooBhaina'),),
                                    Icon(
                                      MdiIcons.google,size: 20,color: Colors.white,
                                    )
                                  ],
                                )
                            ),
                          ],
                        )
                    ),
                  ),
                ),
              ],
            ),
        ),
         );
// This trailing comma makes auto-formatting nicer for build methods.

  }
}


