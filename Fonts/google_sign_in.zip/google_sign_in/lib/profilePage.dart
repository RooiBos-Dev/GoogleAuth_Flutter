
import 'package:flutter/material.dart';
import 'package:flare_flutter/flare_actor.dart';
import 'package:flutter/rendering.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with SingleTickerProviderStateMixin{
  AnimationController _controller;
  Animation animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1),lowerBound: 0,upperBound: 20,
      vsync: this,
    )..addListener(() {
      setState(() {

      });})..addStatusListener((status) {if(status == AnimationStatus.completed){
      _controller.reverse();
    }else if (status == AnimationStatus.dismissed){_controller.forward();}});
    animation = Tween(begin: 0, end: 2).animate(CurvedAnimation(parent: _controller, curve: Curves.bounceIn));
    _controller.forward();
  }

  @override
  void dispose(){
    super.dispose();
    _controller.dispose();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("Hello"),

    );


  }
}
